package main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Registro2
 */
@WebServlet("/Registro2")
public class Registro2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registro2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		CUser User1 = new CUser();
		HttpSession session = request.getSession(false);
		String sessionID = session.getId();
		User1 = (CUser) session.getAttribute(sessionID);
		String Name = request.getParameter("nombre");
		String Apellido = request.getParameter("Apellidos");
		String email = request.getParameter("e-mail");
		String postal = request.getParameter("postal");
		User1.username = Name;
		User1.apellido = Apellido;
		User1.email = email;
		User1.postal = postal;
		PrintWriter toClient = response.getWriter();
		toClient.println("<html>");
		toClient.println("<head><title>Verificacion</title></head>");
		toClient.println("<body><font size=6><b>Ya queda poco " + User1.username + "<br>");
		toClient.println("<br><font size=4>Son todos los datos correctos?<br>");
		toClient.println("<br>Nombre y Apellidos: </b>" + User1.username + " " + User1.apellido + "<br>");
		toClient.println("<br><b>E-Mail: </b>" + User1.email + "<br>");
		toClient.println("<br><b>Direccion Postal: </b>" + User1.postal + "<br></body>");
		toClient.println("<br><form action =\"" + response.encodeURL("Registro3") + "\" method=\"post\">\r\n" + "<input type=\"submit\" value=\"Confirmar\"></form>" + "<form action =\"" + response.encodeURL("Registro") + "\" method=\"post\">\r\n" + "<input type=\"submit\" value=\"Modificar\"></form>");
		toClient.println("</html>");
		session.setAttribute(sessionID,User1);
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
