package main;

public class CUser {
	public String username;
	public String apellido;
	public String email;
	public String postal;
	public String pass;
	int numLista;
	public CUser (String name, String surname, String mail, String correo, String password) {
		this.username = name;
		this.apellido = surname;
		this.email = mail;
		this.postal = correo;
		this.pass = password;
	}
	public CUser() {
		this.numLista = 1;
	}
}
