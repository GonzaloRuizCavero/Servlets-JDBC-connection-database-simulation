package main;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import com.mysql.cj.Session;

import java.net.*;
import java.sql.*;
/**
 * Servlet implementation class Registro3
 */
@WebServlet("/Registro3")
public class Registro3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static int Registro = 1;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registro3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CUser User1 = new CUser();
		HttpSession session = request.getSession(false);
		String sessionID = session.getId();
		User1 = (CUser) session.getAttribute(sessionID);
		// Creamos la conexion y el nuevo usuario en la base de datos
		try {
			String url = "jdbc:mysql://192.168.2.138:3306";
		    String user = "GONZALO";
		    String pass = "Gonzalo1!";
		    Connection connection;
			connection = DriverManager.getConnection(url ,user, pass);
			Statement st = connection.createStatement();
			st.execute("USE LISTA_NOMBRES");
		    PreparedStatement ps = connection.prepareStatement ("INSERT INTO LISTA VALUES (? ,? ,?, ?, ?)") ;
		    ps.setString(1,User1.username);
		    ps.setString(2,User1.apellido);
		    ps.setString(3,User1.pass);
		    ps.setString(4,User1.email);
		    ps.setString(5, User1.postal);
		    ps.executeUpdate();
			PrintWriter toClient = response.getWriter();
			toClient.println("<html>");
			toClient.println("<head><title>Confirmacion</title></head>");
			toClient.println("<body><font size=4>Gracias por su contribucion<br>");
			toClient.println("<br>Sus datos han sido registrados correctamente... </body>");
			session.invalidate();
			connection.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}