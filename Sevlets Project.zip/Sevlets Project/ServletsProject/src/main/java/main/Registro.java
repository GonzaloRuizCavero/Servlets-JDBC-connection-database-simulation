package main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Registro
 */
@WebServlet("/Registro")
public class Registro extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registro() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*HttpSession session = request.getSession(true);
		// Obtain the session Id
		String sessionID = session.getId();
		// Obtain session object
		CUser User = (CUser) session.getAttribute(sessionID);
		System.out.println(session);
		System.out.println("sessionID=" + sessionID);
		if(null == User) {
			User = new CUser("Patxi","Gonzalez","patxi@gmail.com","42109"); // set the object
			session.setAttribute(sessionID, User); // And add to the session
			System.out.println("New User = " + User.username);
		}
		else {
			System.out.println("User = " + User.username);
		}*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); //set the content type of the response
		HttpSession session = request.getSession(true);
		String sessionID = session.getId();
		CUser User = new CUser();
		String url = "jdbc:mysql://192.168.2.138:3306";
		String us = "GONZALO";
		String pass = "Gonzalo1!";
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url,us,pass);
			if (conn != null) {
				System.out.println("Connection Established");
			}

			// Get client's form data
			if (session.isNew() == true){
				User.username = request.getParameter("user");
				User.pass = request.getParameter("pass");
			}
			else {
				User = (CUser) session.getAttribute(sessionID);
			}
			Statement st = conn.createStatement();
			st.execute("USE LISTA_NOMBRES");
			PrintWriter toClient = response.getWriter();
			toClient.println("<html>");
			toClient.println("<head><title>Register</title></head>");
			System.out.println("User = " + User.username);
			// ResultSet rs = st.executeQuery("SELECT EXISTS(SELECT * FROM LISTA WHERE NAME = ' " + User.username + "')");
			ResultSet rs = st.executeQuery("SELECT NAME FROM LISTA WHERE NAME = '" + User.username + "'");
			String name = null;
			while (rs.next()) {
				name = rs.getString(1);
			}
			if (User.username.equals(name)) {
				toClient.println("<body>El usuario " + User.username + " ya existe");
				toClient.println("<a href=\"registro.html\"> Volver </a><body>");
				session.invalidate();
			}
			else // LO que devuelve si el usuario no existe
			{
				toClient.println("<body>");
				toClient.println("Hola "+ User.username +"! Completa el registro");
				toClient.println("<form action =\"" + response.encodeURL("Registro2") + "\" method=\"post\">\r\n" + "<br>Nombre: <input type= \"text\" name=\"nombre\" value = \"" + User.username + "\">\r\n" + "<br>Apellidos: <input type= \"text\" name=\"Apellidos\" value = \"" + User.apellido + "\">\r\n" + "<br>E-Mail: <input type= \"text\" name=\"e-mail\" value = \"" + User.email + "\">\r\n" + "<br>Direccion Postal: <input type= \"text\" name=\"postal\" value = \"" + User.postal + "\">\r\n" + "<br><input type=\"submit\" value=\"Enviar\"><input type=\"reset\" value=\"Restablecer\">");
				toClient.println("</form>");
				toClient.println("</body>");
				session.setAttribute(sessionID, User);
				toClient.println("</html>");
				//Close the writer; the response is done
			}
			toClient.close();
			conn.close();
			// Respond to client
			/*PrintWriter toClient = response.getWriter();
			toClient.println("<html>");
			toClient.println("<head><title>Register</title></head>");
			System.out.println("User = " + User.username);
			// Crear conexion (�Pertenece el usuario y la contrase�a a la base de datos?)
			if (User.username.equals("Jon")) {
				toClient.println("<body>El usuario " + User.username + " ya existe");
				toClient.println("<a href=\"registro.html\"> Volver </a><body>");
				System.out.println("User = " + User.username);
				session.invalidate();
			}
			else // LO que devuelve si el usuario no existe
			{
				toClient.println("<body>");
				toClient.println("Hola "+ User.username +"! Completa el registro");
				toClient.println("<form action =\"" + response.encodeURL("Registro2") + "\" method=\"post\">\r\n" + "<br>Nombre: <input type= \"text\" name=\"nombre\" value = \"" + User.username + "\">\r\n" + "<br>Apellidos: <input type= \"text\" name=\"Apellidos\" value = \"" + User.apellido + "\">\r\n" + "<br>E-Mail: <input type= \"text\" name=\"e-mail\" value = \"" + User.email + "\">\r\n" + "<br>Direccion Postal: <input type= \"text\" name=\"postal\" value = \"" + User.postal + "\">\r\n" + "<br><input type=\"submit\" value=\"Enviar\"><input type=\"reset\" value=\"Restablecer\">");
				toClient.println("</form>");
				toClient.println("</body>");
				session.setAttribute(sessionID, User);
				toClient.println("</html>");
				//Close the writer; the response is done
			}*/
			
			
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
